﻿open System

// List of salaries
let salaries = [75000; 48000; 120000; 190000; 300113; 92000; 36000]

// **Filter high-income salaries (above $100,000)**
let highIncomeSalaries = 
    salaries 
    |> List.filter (fun x -> x > 100000)
printfn "High-income salaries: %A" highIncomeSalaries

// **Calculate tax for all salaries using the map function**
// Federal income tax table:
// - 10% for salaries below $50,000
// - 20% for salaries between $50,000 and $100,000
// - 30% for salaries above $100,000
let calculateTax salary =
    if salary < 50000 then float salary * 0.1
    elif salary <= 100000 then float salary * 0.2
    else float salary * 0.3

let taxes = 
    salaries 
    |> List.map calculateTax
printfn "Taxes for all salaries: %A" taxes

// **Filter salaries less than $49,020 and add $20,000**
let updatedSalaries = 
    salaries 
    |> List.map (fun x -> if x < 49020 then x + 20000 else x)
printfn "Updated salaries (adding $20,000 to those below $49,020): %A" updatedSalaries


let sumOfMultiplesOf3 n =
    let rec helper current sum =
        if current > n then sum
        else helper (current + 3) (sum + current)
    helper 3 0

// Example usage:
let result = sumOfMultiplesOf3 27
printfn "Sum of multiples of 3 up to 27: %d" result



